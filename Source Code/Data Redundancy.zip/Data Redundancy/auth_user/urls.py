from django.contrib import admin
from django.urls import path, include
from . import views
urlpatterns = [
    path('', views.user_auth, name='user_auth'),
    path('register/', views.createUser, name='createUser'),
    path('logout/', views.logout, name='logout'),
    path('edit-profile/', views.edit_profile, name='edit-profile'),
    path('send_otp/', views.send_otp, name='send_otp'),
    path('edit-profile-pic/', views.edit_profile_pic, name='edit-profile-pic'),
    path('forgot_password/', views.forgot_password, name='forgot_password'),
    path('send_forgot_otp/', views.send_forgot_otp, name='send_forgot_otp'),
]