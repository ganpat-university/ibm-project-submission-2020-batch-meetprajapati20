from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
import pymongo
from .utils import get_db_handle
import datetime
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from django.contrib.auth.models import User
import json
from bson import json_util
from mail import send_mail
import geocoder
import hashlib
import base64
from uuid import uuid4
# from django.core.mail import send_mail

# Create your views here.

db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)
def createUser(request):
    db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)
    if request.method == 'POST':
        username = request.POST['uEmail']
        password = request.POST['uPassword']
        firstname = request.POST['uFirstName']
        lastname = request.POST['uLastName']
        phone = request.POST['uPhone']
        createdAt = datetime.datetime.now()

        db_handle = client['drr']
        user = db_handle['users'].find_one({'username': username})
        if user is not None:
            return HttpResponse('User already exists')
        else:
            User.objects.create_user(username=username, password=password, first_name=firstname, last_name=lastname)
            sha_password = hashlib.sha256(password.encode()).hexdigest()
            db_handle['users'].insert_one({'username': username, 'password': sha_password, 'firstname': firstname, 'lastname': lastname, 'phone': phone, 'createdAt': createdAt})
            return HttpResponse('success', status=200)
    else:
        return render(request, 'signup.html')
    
def user_auth(request):
    # db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)

    if request.method == 'POST':
        username = request.POST.get('uEmail')
        password = request.POST.get('uPassword')
        otp = request.POST.get('otp')
        db_handle = client['drr']
        if otp:
            if request.session.get('otp') != otp:
                return HttpResponse('Invalid OTP', status=400)
        else:
            return HttpResponse('OTP is required', status=400)
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            sha_password = hashlib.sha256(password.encode()).hexdigest()
            user = db_handle['users'].find_one({'username': username, 'password': sha_password})
            if user is None:
                return HttpResponse('Invalid Credentials', status=400)
            if user.get('is_locked', False):
                return HttpResponse('Your account is locked. Please reset your password to unlock your account.', status=400)
            json_user = json.loads(json_util.dumps(user))
            get_user = User.objects.get(username=username)
            ip_address = ''
            if 'HTTP_X_FORWARDED_FOR' in request.META:
                ip_address = request.META['HTTP_X_FORWARDED_FOR']
            else:
                ip_address = request.META['REMOTE_ADDR']

            city = ''
            state = ''
            g = geocoder.ip(ip_address)
            if g.city:
                city = g.city
            if g.state:
                state = g.state
            if ip_address == '127:0:0:1':
                city = 'Ahmedabad'
                state = 'Gujarat'

            log_data = {
                'username': username,
                'login_time': datetime.datetime.now(),
                'ip_address': ip_address,
                'city': city,
                'state': state,
                "status": "success"
            }
            db_handle['login_logs'].insert_one(log_data)
            auth.login(request, get_user)
            request.session['user'] = json_user
            created_at = json_user['createdAt']
            request.session['createdAt'] = created_at
            request.session.set_expiry(7200)
            db_handle['users'].update_one({'username': username}, {'$set': {'no_of_try': 0}})
            return HttpResponse('success')
        else:
            user_data = db_handle['users'].find_one({'username': username})
            no_try = user_data.get('no_of_try', 0)
            db_handle['users'].update_one({'username': username}, {'$set': {'no_of_try': int(no_try)+1}})
            if no_try >= 3:
                if no_try == 3:
                    link = str(uuid4())
                    subject = "DRRS - Account Locked"
                    message = """
                    Hello %s,
                    Your account has been temporarily locked due to multiple failed login attempts. Please reset your password to unlock your account.<br>
                    Click on the link below to verify your email address and you will be redirected to login page for further process.<br>
                    http://%s/verify_email/%s<br>
                        <br>
                    Note: If you have not requested this, please contact us immediately.<br>
                    Regards,
                    DRRS Team
                    """%(username, request.get_host(), link)
                    from_email = 'meetprajapati20@gnu.ac.in'
                    to_email = [username]
                    send_mail(from_email, to_email, subject, message)
                    db_handle['users'].update_one({'username': username}, {'$set': {'link': link,'is_locked': True}})
                return HttpResponse('Your account is locked. Please reset your password to unlock your account. Or verify your email address.', status=400)
            
            ip_address = ''
            if 'HTTP_X_FORWARDED_FOR' in request.META:
                ip_address = request.META['HTTP_X_FORWARDED_FOR']
            else:
                ip_address = request.META['REMOTE_ADDR']

            city = ''
            state = ''
            g = geocoder.ip(ip_address)
            if g.city:
                city = g.city
            if g.state:
                state = g.state
            if ip_address == '127:0:0:1':
                city = 'Ahmedabad'
                state = 'Gujarat'

            db_handle['login_logs'].insert_one({
                'username': username,
                'login_time': datetime.datetime.now(),
                'ip_address': ip_address,
                'city': city,
                'state': state,
                "status": "failed"
            })
            return HttpResponse('Invalid Credentials')
    else:
        return render(request, 'login.html')

def otp_generate():
    import uuid
    otp = uuid.uuid4().hex[:6].upper()
    otp = str(otp)
    return otp

def send_otp(request):
    if request.method == 'POST':
        email = request.POST.get('uEmail')
        db_handle = client['drr']
        user = db_handle['users'].find_one({'username': email})
        if user is not None:
            otp = otp_generate()        
            request.session['otp'] = otp
            request.session.set_expiry(300)

            subject = "DRRS - OTP Verification"
            message = """
            Hello,
            Your OTP for DRRS is: %s <br>
            Please do not share this OTP with anyone.<br>

            Go to the link below to verify your email address:<br>
            http://%s/
            Regards,
            DRRS Team
            """ % (otp, request.get_host())
            from_email = 'meetprajapati20@gnu.ac.in'
            to_email = [email]
            print('OTP:', otp)
            print('Email:', email)
            send_mail(from_email, to_email, subject, message)
            return HttpResponse('success', status=200)
        else:
            return HttpResponse('User does not exist')


def edit_profile(request):
    if request.method == 'POST':
        db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)
        username = request.session['user']['username']
        firstname = request.POST.get('first_name')
        lastname = request.POST.get('last_name')
        phone = request.POST.get('phone')
        db_handle = client['drr']
        user = db_handle['users'].find_one({'username': username})
        if user is not None:
            db_handle['users'].update_one({'username': username}, {'$set': {'firstname': firstname, 'lastname': lastname, 'phone': phone, 'updatedAt': datetime.datetime.now()}})
            request.session['user']['firstname'] = firstname
            request.session['user']['lastname'] = lastname
            request.session['user']['phone'] = phone
            return HttpResponse('success', status=200)
        else:
            return HttpResponse('User does not exist')
    else:
        return render(request, 'profile.html')


def edit_profile_pic(request):
    if request.method == 'POST':
        db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)
        username = request.session['user']['username']
        db_handle = client['drr']
        user = db_handle['users'].find_one({'username': username})
        if user is not None:
            profile_pic = request.FILES['profile_pic']
            base64_image = base64.b64encode(profile_pic.read())
            profile_pic = base64_image.decode('utf-8')
            db_handle['users'].update_one({'username': username}, {'$set': {'profile_pic': profile_pic, 'updatedAt': datetime.datetime.now()}})
            request.session['user']['profile_pic'] = profile_pic
            return HttpResponse('success', status=200)
        else:
            return HttpResponse('User does not exist')
    else:
        return render(request, 'profile.html')

def send_forgot_otp(request):
    if request.method == 'POST':
        email = request.POST.get('uEmail')
        db_handle = client['drr']
        user = db_handle['users'].find_one({'username': email})
        if user is not None:
            otp = otp_generate()        
            request.session['forgot_otp'] = otp
            request.session.set_expiry(300)

            subject = "DRRS - OTP Verification"
            message = """
            Hello,
            Your OTP for DRRS is: %s <br>
            Please do not share this OTP with anyone.<br>

            Go to the link below to verify your email address:<br>
            http://%s/
            Regards,
            DRRS Team
            """ % (otp, request.get_host())
            from_email = 'meetprajapati20@gnu.ac.in'
            to_email = [email]
            send_mail(from_email, to_email, subject, message)
            return HttpResponse('success', status=200)
        else:
            return HttpResponse('User does not exist')
    else:
        return HttpResponse('Invalid Request', status=400)

def verify_email(request, link):
    db_handle = client['drr']
    user = db_handle['users'].find_one({'link': link})
    if user is not None:
        db_handle['users'].update_one({'link': link}, {'$set': {'is_locked': False, 'link': '', 'no_of_try': 0}})
        return render(request, 'login.html')
    else:
        return HttpResponse('Invalid Link', status=400)
    

def forgot_password(request):
    if request.method == 'POST':
        email = request.POST.get('uEmail')
        password = request.POST.get('uPassword')
        otp = request.POST.get('otp')
        db_handle = client['drr']
        if otp:
            if request.session.get('forgot_otp') != otp:
                return HttpResponse('Invalid OTP', status=400)
        else:
            return HttpResponse('OTP is required', status=400)
        user = db_handle['users'].find_one({'username': email})
        if user is not None:
            sha_password = hashlib.sha256(password.encode()).hexdigest()
            db_handle['users'].update_one({'username': email}, {'$set': {'password': sha_password, 'updatedAt': datetime.datetime.now(), 'is_locked': False, 'link': '', 'no_of_try': 0}})
            request.session['forgot_otp'] = 'forgot_otp'
            return HttpResponse('success', status=200)
        else:
            return HttpResponse('User does not exist', status=400)
    else:
        return HttpResponse('Invalid Request', status=400)

def logout(request):
    if auth.get_user(request).is_authenticated:
        auth.logout(request)
    try:
        del request.session['user']
    except:
        pass
    return HttpResponse('success', status=200)