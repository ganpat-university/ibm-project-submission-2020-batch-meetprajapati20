from django.shortcuts import render
from django.http import HttpResponse
import pymongo
from .utils import get_db_handle
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from pymongo import MongoClient
from gridfs import GridFS
import os
import pandas as pd
import numpy as np
import bson
import json
import datetime
import time
import re
import csv
import sys
import math
import random
import string
import traceback
from mail import send_mail
import geocoder
# from django.core.mail import send_mail

# Create your views here.
db_handle, client = get_db_handle(db_name='drr',host="localhost",port=int(27017),username=None,password=None)

def get_client_ip_city(request):
    client_ip, city = None, None
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        client_ip = x_forwarded_for.split(',')[0]
    else:
        client_ip = request.META.get('REMOTE_ADDR')
    try:
        g = geocoder.ip(client_ip)
        city = g.city
    except Exception as e:
        print(e)
        city = 'Unknown'
    return client_ip, city

@login_required
def home(request):
    ip, city = get_client_ip_city(request)
    print(f"IP: {ip}, City: {city}")
    return render(request, 'index.html')

def login(request):
    if request.user.is_authenticated:
        return render(request, 'index.html')
    return render(request, 'login.html')

def aboutus(request):
    return render(request, 'about.html')

@login_required
def profile(request):
    data = {}
    db_handle = client['drr']
    collection = db_handle['users']
    user = collection.find_one({'username': request.user.username})
    data['user_data'] = user
    if 'createdAt' in user:
        data['createdAt'] = user['createdAt'].strftime('%Y-%m-%d %H:%M:%S')
    if 'updatedAt' in user:
        data['updatedAt'] = user['updatedAt'].strftime('%Y-%m-%d %H:%M:%S')
    else:
        data['updatedAt'] = user['createdAt']
    files = []
    if 'files' in user:
        if len(user['files']) > 0:
            for file in user['files']:
                files.append({'fs_id': file[0], 'filename': file[1], 'uploaded_at': file[2].strftime('%Y-%m-%d %H:%M:%S')})
        else:
            files = []
    else:
        files = []
    
    if 'profile_pic' in user:
        data['profile_pic'] = user['profile_pic']
    
    collection = db_handle['login_logs']
    login_logs = collection.find({'username': request.user.username}, {'_id': 0}).sort('login_time', -1)
    sec_last = list(login_logs)
    if len(sec_last) > 1:
        data['last_login'] = sec_last[1]['login_time'].strftime('%Y-%m-%d %H:%M:%S')
    else:
        data['last_login'] = 'First Login'
    data['files'] = files
    return render(request, 'profile.html', data)

def signup(request):
    return render(request, 'signup.html')

@login_required
@csrf_exempt
def upload_file(request):
    if request.method == 'POST' and request.FILES['file']:
        try:
            uploaded_file = request.FILES['file']
            db_handle = client['drr']
            collection = db_handle['users']
            fs = GridFS(db_handle)
            # Store file in MongoDB and file metadata in a users collection
            fs_id = fs.put(uploaded_file, filename=uploaded_file.name)
            fs_name = fs.get(fs_id).filename
            collection.update_one({'username': request.user.username}, {'$push': {'files': [fs_id,fs_name, datetime.datetime.now()]}}, upsert=True)
            ip_address, city = get_client_ip_city(request)
            log_data = {
                'username': request.user.username,
                'file_name': fs_name,
                'uploaded_at': datetime.datetime.now(),
                'ip_address': ip_address,
                'city': city,
                'status': 'success'
            }
            db_handle['file_logs'].insert_one(log_data)
            return JsonResponse({'status': 'success', 'fs_id': str(fs_id), 'fs_name': fs_name}, status=200)
        except Exception as e:
            print(e)
            log_data = {
                'username': request.user.username,
                'file_name': fs_name,
                'uploaded_at': datetime.datetime.now(),
                'ip_address': ip_address,
                'city': city,
                'status': 'failure'
            }
            db_handle['file_logs'].insert_one(log_data)
            return JsonResponse({'status': 'failure'}, status=500)
    else:
        return JsonResponse({'status': 'failure'}, status=500)

def get_file_description(request):
    try:
        db_handle = client['drr']
        fs = GridFS(db_handle)
        fs_id = request.GET['fs_id']
        filename = fs.get(bson.objectid.ObjectId(fs_id)).filename
        file = fs.get(bson.objectid.ObjectId(fs_id))
        file_description = {}
        
        df = pd.read_csv(file)
        rows, columns = df.shape
        file_description['filename'] = filename
        file_description['size_in_kb'] = str(round(file.length/1024, 2))
        file_description['file_type'] = filename.split('.')[-1]
        file_description['rows'] = rows
        file_description['columns'] = columns
        file_description['column_names'] = list(df.columns)
        file_description['column_types'] = [str(i) for i in list(df.dtypes)]
        file_description['column_nulls'] = [str(df[i].isnull().sum() )for i in list(df.columns)]
        file_description['column_unique'] = [str(len(df[i].unique()) )for i in list(df.columns)]
        numeric = [i for i in list(df.columns) if df[i].dtype in [np.int64, np.float64]]
        file_description['numeric_columns'] = [i for i in list(df.columns) if df[i].dtype in [np.int64, np.float64]]
        file_description['column_max'] = [str(round(df[i].max(),2)) for i in numeric]
        file_description['column_min'] = [str(round(df[i].min(),2)) for i in numeric]
        file_description['column_mean'] = [str(round(df[i].mean(),2)) for i in numeric]
        file_description['column_median'] = [str(round(df[i].median(),2)) for i in numeric]
        file_description['column_mode'] = [str(round(df[i].mode()[0],2)) for i in numeric]
        file_description['column_std'] = [str(round(df[i].std(),2)) for i in numeric]
        file_description['column_skew'] = [str(round(df[i].skew(),2)) for i in numeric]
        return JsonResponse({'status': 'success', 'data': file_description})
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure'})

def get_files(request):
    try:
        db_handle = client['drr']
        collection = db_handle['users']
        user = collection.find_one({'username': request.user.username})
        files = user['files']
        fs = GridFS(db_handle)
        file_list = []
        for file in files:
            file_list.append(fs.get(file).filename)
        return JsonResponse({'files': file_list})
    except Exception as e:
        print(e)
        return JsonResponse({'status': 'failure'})

def download_file(request):
    try:
        db_handle = client['drr']
        fs = GridFS(db_handle)
        file = fs.get(bson.objectid.ObjectId(request.POST['file_id']))
        response = HttpResponse(file.read(), content_type='application/force-download')
        response['Content-Disposition'] = 'attachment; filename=%s.csv' % file.filename
        return response
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure'})

    
def delete_file(request):
    try:
        db_handle = client['drr']
        collection = db_handle['users']
        fs = GridFS(db_handle)
        file = fs.get(request.GET['file'])
        fs.delete(file._id)
        collection.update_one({'username': request.user.username}, {'$pull': {'files': request.GET['file']}})
        return JsonResponse({'status': 'success'})
    except Exception as e:
        print(e)
        return JsonResponse({'status': 'failure'})


# File duplication removal
import pandas as pd
import numpy as np

class CWOA:
    def __init__(self, data, max_iterations):
        self.data = data
        self.max_iterations = max_iterations

    def initialize_whales(self):
        return np.random.randint(0, 2, size=len(self.data))

    def search(self):
        X = self.initialize_whales()
        best_solution = X.copy()
        best_fitness = self.fitness(X)

        for _ in range(self.max_iterations):
            chaos_value = self.calculate_chaos_value()
            A = self.calculate_A(chaos_value)
            p = np.random.random()

            for i in range(len(X)):
                if p != 0.5:
                    if abs(A) != 1:
                        X[i] = self.update_position(X[i])
                    else:
                        random_agent_index = np.random.randint(0, len(X))
                        X[random_agent_index] = self.update_position(X[random_agent_index])
                else:
                    X[i] = self.update_position(X[i])

            fitness = self.fitness(X)
            if fitness < best_fitness:
                best_solution = X.copy()
                best_fitness = fitness

        return best_solution

    def fitness(self, solution):
        # fitness can be the number of unique records
        unique_records = set()
        for i in range(len(solution)):
            if solution[i] == 1:
                unique_records.add(tuple(self.data.iloc[i]))
        return len(unique_records)

    def calculate_chaos_value(self):
        # Implement your method to calculate the chaos value
        # This could be a random value or calculated using a chaotic map
        return np.random.random()

    def calculate_A(self, chaos_value):
        # Implement your method to calculate A based on chaos value
        return 2 * chaos_value - 1

    def update_position(self, agent):
        # Implement your method to update the position of the agent
        # Here, you might flip the value of the agent (0 to 1 or vice versa)
        return 1 - agent      


def initialize_cwoa(request):
    try:
        fs_id = request.GET.get('fs_id')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)
        data = df.copy()

        # Initialize CWOA with data and maximum iterations
        cwoa = CWOA(data, max_iterations=1000)
        return JsonResponse({'status': 'success', 'fs_id': fs_id}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)

def execute_cwoa(request):
    try:
        fs_id = request.GET.get('fs_id')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)
        data = df.copy()

        # Initialize CWOA with data and maximum iterations
        cwoa = CWOA(data, max_iterations=1000)
        
        # Execute CWOA to find unique records
        best_solution = cwoa.search()
        best_solution = best_solution.tolist()
        return JsonResponse({'status': 'success', 'best_solution': best_solution, 'fs_id': fs_id}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)

def extract_unique_records(request):
    try:
        # Retrieve parameters from request
        best_solution = json.loads(request.GET.get('best_solution'))
        fs_id = request.GET.get('fs_id')

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        data = pd.read_csv(file)

        # Extract unique records based on best solution        
        unique_records = []
        for i in range(len(best_solution)):
            if best_solution[i] == 1:
                unique_records.append(data.iloc[i])

        # store csv in mongodb
        unique_records_df = pd.DataFrame(unique_records)
        unique_records_file = f"unique_records_{fs_id}.csv"
        unique_records_df.to_csv(unique_records_file, index=False)
        fs_id = fs.put(open(unique_records_file, 'rb'), filename=unique_records_file)
        os.remove(unique_records_file)

        return JsonResponse({'status': 'success', 'fs_id': str(fs_id)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)
    
def download(request):
    try:
        db_handle = client['drr']
        fs = GridFS(db_handle)
        file = fs.get(bson.objectid.ObjectId(request.GET['fs_id']))
        response = HttpResponse(file.read(), content_type='application/force-download')
        response['Content-Disposition'] = 'attachment; filename=%s' % file.filename
        return response
    except Exception as e:
        print(e)
        return JsonResponse({'status': 'failure'})
    
# Exact match record removal
def remove_exact_duplicates_data(data):
    return data.drop_duplicates()

def remove_exact_duplicates(request):
    try:
        fs_id = request.GET.get('fs_id')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        data = pd.read_csv(file)
        data = data.dropna()

        # Remove exact duplicates
        data = remove_exact_duplicates_data(data)

        # store csv in mongodb
        data_file = f"unique_records_{fs_id}.csv"
        data.to_csv(data_file, index=False)
        fs_id = fs.put(open(data_file, 'rb'), filename=data_file)
        os.remove(data_file)

        return JsonResponse({'status': 'success', 'fs_id': str(fs_id)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)

# Fuzzy match record removal
from fuzzywuzzy import fuzz
def remove_fuzzy_duplicates(request):
    try:
        fs_id = request.GET.get('fs_id')
        threshold = request.GET.get('threshold')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)
        
        # Remove fuzzy duplicates
        data = [tuple(row) for row in df.values]
    
        # Remove duplicates using fuzzy matching
        unique_records = remove_duplicates_fuzzy(data, threshold=threshold)
        
        # Convert the unique records back to a DataFrame
        unique_df = pd.DataFrame(unique_records, columns=df.columns)

        # store csv in mongodb
        unique_records_file = f"fuzzy_unique_records_{fs_id}.csv"
        unique_df.to_csv(unique_records_file, index=False)
        fs_id = fs.put(open(unique_records_file, 'rb'), filename=unique_records_file)
        os.remove(unique_records_file)
        db_handle['users'].update_one({'username': request.user.username}, {'$push': {'files': [fs_id, unique_records_file, datetime.datetime.now()]}}, upsert=True)
        return JsonResponse({'status': 'success', 'fs_id': str(fs_id)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)
    
def remove_duplicates_fuzzy(data, threshold=80):
    unique_records = []
    for i, record1 in enumerate(data):
        is_duplicate = False
        for j, record2 in enumerate(unique_records):
            similarity_score = fuzz.ratio(record1, record2)
            if similarity_score >= int(threshold):
                is_duplicate = True
                break
        if not is_duplicate:
            unique_records.append(record1)
    return unique_records
    

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.cluster import KMeans

# Preprocess the dataset from a CSV file
def preprocess_dataset(df):
    
    # Separate numeric and non-numeric columns
    numeric_columns = df.select_dtypes(include=[np.number]).columns
    non_numeric_columns = df.select_dtypes(exclude=[np.number]).columns
    
    # Encode non-numeric columns
    encoded_data = pd.DataFrame()
    for column in non_numeric_columns:
        encoder = LabelEncoder()
        encoded_data[column] = encoder.fit_transform(df[column])
    
    # Impute missing values
    imputer = SimpleImputer(strategy='mean')
    numeric_data_imputed = imputer.fit_transform(df[numeric_columns])
    
    # Scale numeric columns
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(numeric_data_imputed)
    
    # Combine scaled numeric and encoded non-numeric data
    X = np.concatenate((scaled_data, encoded_data), axis=1)
    
    return X, df

#  Use K-means to identify duplicate records
def identify_duplicates(X):
    kmeans = KMeans(n_clusters=2, random_state=42)  # two clusters (duplicates and non-duplicates)
    kmeans.fit(X)
    labels = kmeans.labels_
    return labels

#  Remove duplicate records from the dataset
def remove_duplicates_from_dataset(X, df, labels):
    df['Labels'] = labels
    df_unique = df[df['Labels'] == 1].drop(columns=['Labels'])
    return df_unique

def mdnn_remove_duplicates(request):
    try:
        fs_id = request.GET.get('fs_id')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)

        # Load data and preprocess
        X_scaled, original_df = preprocess_dataset(df)  

        # Identify duplicate records using K-means
        labels = identify_duplicates(X_scaled)

        # Remove duplicate records from the dataset
        cleaned_df = remove_duplicates_from_dataset(X_scaled, original_df, labels)
        
        # store csv in mongodb
        unique_records_file = f"mdnn_unique_records_{fs_id}.csv"
        cleaned_df.to_csv(unique_records_file, index=False)
        fs_id = fs.put(open(unique_records_file, 'rb'), filename=unique_records_file)
        os.remove(unique_records_file)

        db_handle['users'].update_one({'username': request.user.username}, {'$push': {'files': [fs_id, unique_records_file, datetime.datetime.now()]}}, upsert=True)

        return JsonResponse({'status': 'success', 'fs_id': str(fs_id)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)
    

# To remove duplicate records based on a selection of columns
def remove_duplicates_by_columns_fun(df, columns):
    return df.drop_duplicates(subset=columns)

def remove_duplicates_by_columns(request):
    try:
        fs_id = request.GET.get('fs_id')
        selected_columns = request.GET.get('selected_columns')

        columns = json.loads(selected_columns)
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)
        if not columns:
            return JsonResponse({'status': 'failure', 'message': 'columns is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)

        # Remove duplicates based on selected columns
        cleaned_df = remove_duplicates_by_columns_fun(df, columns)
        
        # store csv in mongodb
        unique_records_file = f"dup_by_col_unique_records_{fs_id}.csv"
        cleaned_df.to_csv(unique_records_file, index=False)
        fs_id = fs.put(open(unique_records_file, 'rb'), filename=unique_records_file)
        os.remove(unique_records_file)
        db_handle['users'].update_one({'username': request.user.username}, {'$push': {'files': [fs_id, unique_records_file, datetime.datetime.now()]}}, upsert=True)

        return JsonResponse({'status': 'success', 'fs_id': str(fs_id)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)
    

def functional_depandancy(df):
    functional_dependencies = {}
    for col1 in df.columns:
        for col2 in df.columns:
            if col1 == col2:  # Skip self-comparison
                continue
            # Check if col1 uniquely determines col2
            if df[[col1, col2]].drop_duplicates().shape[0] == df[col1].nunique():
                # Check if the dependency is already added or not
                dependency_added = False
                for key, values in functional_dependencies.items():
                    if col2 in values:
                        dependency_added = True
                        break
                if not dependency_added:
                    # Add functional dependency to the dictionary
                    if col1 not in functional_dependencies:
                        functional_dependencies[col1] = [col2]
                    else:
                        functional_dependencies[col1].append(col2)
    return functional_dependencies
    

def remove_redundancy(request):
    try:
        fs_id = request.GET.get('fs_id')
        if not fs_id:
            return JsonResponse({'status': 'failure', 'message': 'fs_id is required'}, status=400)

        # Connect to MongoDB
        db_handle = client['drr']
        fs = GridFS(db_handle)

        # Retrieve the file from GridFS
        file = fs.get(bson.objectid.ObjectId(fs_id))
        if not file:
            return JsonResponse({'status': 'failure', 'message': 'File not found'}, status=404)

        # Read CSV data
        df = pd.read_csv(file)
        functional_dependencies = functional_depandancy(df)
                  
        functional_dependencies_set = []
        functional_dependencies1 = {}

        # Print identified functional dependencies
        for key, values in functional_dependencies.items():
            print(f'{key} -> {values}')
            if set([key] + values) not in functional_dependencies_set:
                functional_dependencies_set.append(set([key] + values))
                functional_dependencies1[key] = values

        functional_dependencies = functional_dependencies1

            

        tables = {}
        for key, values in functional_dependencies.items():
            table_data = df[[key] + values].drop_duplicates()
            tables[key] = table_data

        list_table_ids = []
        ip_address, city = get_client_ip_city(request)
        # Write each table to a separate CSV file
        for i, (table_name, table_data) in enumerate(tables.items(), start=1):
            table_file = f"{table_name}_table_{fs_id}.csv"
            table_data.to_csv(table_file, index=False)
            fs_id1 = fs.put(open(table_file, 'rb'), filename=table_file)
            print(str(fs_id1))
            list_table_ids.append(str(fs_id1))
            os.remove(table_file)
            log_data = {
                'username': request.user.username,
                'file_name': table_file,
                'uploaded_at': datetime.datetime.now(),
                'ip_address': ip_address,
                'city': '',
                'status': 'success'
            }
            db_handle['file_logs'].insert_one(log_data)
            db_handle['users'].update_one({'username': request.user.username}, {'$push': {'files': [fs_id1, table_file, datetime.datetime.now()]}}, upsert=True)


        

        return JsonResponse({'status': 'success', 'fs_id': str(fs_id), 'list_table_ids': list_table_ids, 'functional_dependencies': json.dumps(functional_dependencies)}, status=200)
    except Exception as e:
        traceback.print_exc()
        return JsonResponse({'status': 'failure', 'message': str(e)}, status=500)


