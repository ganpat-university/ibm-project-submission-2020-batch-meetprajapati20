from django.contrib import admin
from django.urls import path, include
from . import views
from auth_user import views as auth_views
urlpatterns = [
    path('', views.login, name='home'),
    path('upload/', views.upload_file, name='upload_file'),
    path('get_file_description/', views.get_file_description, name='get_file_description'),
    path('initialize_cwoa/', views.initialize_cwoa, name='initialize_cwoa'),
    path('extract_unique_records/', views.extract_unique_records, name='extract_unique_records'),
    path('execute_cwoa/', views.execute_cwoa, name='execute_cwoa'),

    path('remove_exact_duplicates/', views.remove_exact_duplicates, name='remove_exact_duplicates'),
    path('remove_fuzzy_duplicates/', views.remove_fuzzy_duplicates, name='remove_fuzzy_duplicates'),
    path('mdnn_remove_duplicates/', views.mdnn_remove_duplicates, name='mdnn_remove_duplicates'),
    path('remove_duplicates_by_columns/', views.remove_duplicates_by_columns, name='remove_duplicates_by_columns'),
    path('download/', views.download, name='download'),
    path('download_file/', views.download_file, name='download_file'),
    
    path('about-us/', views.aboutus, name='about-us'),

    path('profile/', views.profile, name='profile'),
    # 
    path('loggedin', views.home, name='home'),
    path('register', views.signup, name='signup'),
    path('verify_email/<str:link>', auth_views.verify_email, name='verify_email'),
    path('remove_redundancy/', views.remove_redundancy, name='remove_redundancy'),
    # path('send_mail', views.sendmail, name='home'),
]