
$(document).ready(function () {
    $('#showPasswordId').click(function () {
        if ($('#showPasswordId').prop('checked')) {
            $('#uPassword').attr('type', 'text');
        } else {
            $('#uPassword').attr('type', 'password');
        }
    });

    $("#sendOTP").click(function (e) {
        e.preventDefault();
        console.log('sendOTP');
        var uEmail = $('#uEmail').val();
        if (uEmail == '') {
            alert('Please enter email');
            return;
        }

        $.ajax({
            url: '/auth_user/send_otp/',
            type: 'POST',
            data: {
                uEmail: uEmail,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (response) {
                if (response == 'success') {
                    alert('OTP sent successfully');
                } else {
                    alert(response);
                }
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    });

    $('#loginForm').submit(function (e) {
        e.preventDefault();
        var uEmail = $('#uEmail').val();
        var uPassword = $('#uPassword').val();
        var otp = $('#uOTP').val();
        // var remember = $('#remember').prop('checked');
        if (uEmail == '' || uPassword == '' || otp == '') {
            alert('Please enter email, password and otp');
            return;
        }
        $.ajax({
            url: '/auth_user/',
            type: 'POST',
            data: {
                uEmail: uEmail,
                uPassword: uPassword,
                otp: otp,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (response) {
                if (response == 'success') {
                    console.log('login success');
                    window.location.href = '/loggedin';
                } else {
                    console.log('login failed');
                    message = response;
                    alert(message);
                    $('#loginFailed').removeClass('d-none');
                }
            },
            error: function (xhr, status, error) {
                if (status == 401) {
                    $('#loginFailed').removeClass('d-none');
                } else {
                    alert(xhr.responseText);
                }
            }
        });
    });

    $('#signupForm').submit(function (e) {
        e.preventDefault();
        var uEmail = $('#uEmail').val();
        var uPassword = $('#uPassword').val();
        var uFirstName = $('#ufirstName').val();
        var uLastName = $('#ulastName').val();
        var uPhone = $('#uPhone').val();
        $.ajax({
            url: '/auth_user/register/',
            type: 'POST',
            data: {
                uEmail: uEmail,
                uPassword: uPassword,
                uFirstName: uFirstName,
                uLastName: uLastName,
                uPhone: uPhone,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (response) {
                console.log(response);
                if (response == 'success') {
                    console.log('signup success');
                    window.location.href = '/';
                } else {
                    console.log('signup failed');
                    // $('#signupFailed').removeClass('d-none');
                }
            },
            error: function (response) {
                if (response.status == 401) {
                    console.log('signup failed');
                    // $('#signupFailed').removeClass('d-none');
                }
            }
        });
    });


    $("#sendForgotOTP").click(function (e) {
        e.preventDefault();
        var uEmail = $('#uEmail').val();
        if (uEmail == '') {
            alert('Please enter email');
            return;
        }
        $.ajax({
            url: '/auth_user/send_forgot_otp/',
            type: 'POST',
            data: {
                uEmail: uEmail,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (response) {
                if (response == 'success') {
                    alert('OTP sent successfully');
                } else {
                    alert(response);
                }
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    });

    $("#forgotPasswordForm").submit(function (e) {
        e.preventDefault();
        var uEmail = $('#uEmail').val();
        if (uEmail == '') {
            alert('Please enter email');
            return;
        }
        var otp = $('#forgotOTP').val();
        var uPassword = $('#newPassword').val();
        var uConfirmPassword = $('#confirmPassword').val();
        if (uPassword == '' || uConfirmPassword == '') {
            alert('Please enter password and confirm password');
            return;
        }
        if (uPassword != uConfirmPassword) {
            alert('Password and confirm password should be same');
            return;
        }
        $.ajax({
            url: '/auth_user/forgot_password/',
            type: 'POST',
            data: {
                uEmail: uEmail,
                otp: otp,
                uPassword: uPassword,
                csrfmiddlewaretoken: $('input[name=csrfmiddlewaretoken]').val()
            },
            success: function (response) {
                if (response == 'success') {
                    alert('Password reset successfully');
                } else {
                    alert(response);
                }
                window.location.reload();
            },
            error: function (xhr, status, error) {
                alert(xhr.responseText);
            }
        });
    });
});